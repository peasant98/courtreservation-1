from django.apps import AppConfig


class Courts1Config(AppConfig):
    name = 'courts1'
